
Overlayy_Kanae - listo para GitHub Pages, OBS y Safari iOS.

Estructura:
- index.html
- css/styles.css
- gifs/ (tus GIFs)
- icons/ (SVG icons)
- config.json

Subir a GitHub Pages:
1. Crear repo público.
2. Subir carpeta completa.
3. Settings -> Pages -> main branch, root.
4. URL example: https://TUUSUARIO.github.io/overlayy-kanae/

Uso en OBS:
- Añadir Browser Source y usar la URL o archivo local index.html.
- Ajustar resolución 1920x1080.
Uso en iPhone:
- Abrir index.html en Safari desde Archivos.

